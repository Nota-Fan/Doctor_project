import flet as ft
from api.hospital_api import HospitalAPI

def main(page: ft.Page):
    page.title = "МедЦентр 1С — Личный кабинет" 
    page.theme_mode = ft.ThemeMode.LIGHT
    page.window_width = 1200  # Расширяем окно под 3 колонки
    page.window_height = 800 
    api = HospitalAPI() 
    user_appointments=api.load_all_appointments 
    # Сессия теперь хранит и имя пользователя
    session = {"phone": "", "user_name": "", "doctor": None, "date": ""}

    # --- ЭКРАН ВХОДА ---
    def show_login_screen():
        page.clean()
        phone_tf = ft.TextField(label="Номер телефона", value="9001234567", width=300)
        
        def on_login(e):
            if api.verify_login(phone_tf.value, pass_tf.value):
                user_data = api.get_user_data(phone_tf.value)
                session["phone"] = phone_tf.value
                session["user_name"] = user_data["name"]
                show_dashboard_screen() # Уходим в личный кабинет
            else:
                error_text.value = "Ошибка! Попробуйте пароль 1234"
                page.update()

        pass_tf = ft.TextField(label="Пароль", password=True, width=300, on_submit=on_login)
        error_text = ft.Text("", color="red")
        
        page.add(
            ft.Column([
                ft.Text("Вход в систему", size=30, weight="bold"),
                phone_tf, pass_tf, error_text,
                ft.ElevatedButton("Войти", on_click=on_login, width=300),
                ft.TextButton("Нет аккаунта? Зарегистрироваться", 
                              on_click=lambda _: show_register_screen())
            ], horizontal_alignment=ft.CrossAxisAlignment.CENTER)
        )
        page.update()

    # --- ЭКРАН РЕГИСТРАЦИИ ---
    def show_register_screen():
        page.clean()
        new_name = ft.TextField(label="Ваше ФИО", width=300)
        new_phone = ft.TextField(label="Номер телефона", width=300)
        new_pass = ft.TextField(label="Придумайте пароль", password=True, width=300)
        reg_error = ft.Text("", color="red")

        def perform_reg(e):
            if new_phone.value and new_pass.value and new_name.value:
                if api.register_user(new_phone.value, new_pass.value, new_name.value):
                    session["phone"] = new_phone.value
                    session["user_name"] = new_name.value
                    show_dashboard_screen()
                else:
                    reg_error.value = "Этот номер уже занят!"
                    page.update()
            else:
                reg_error.value = "Заполните все поля!"
                page.update()

        page.add(
            ft.Column([
                ft.Text("Регистрация", size=30, weight="bold"),
                new_name, new_phone, new_pass, reg_error,
                ft.ElevatedButton("Создать аккаунт", on_click=perform_reg, width=300),
                ft.TextButton("Назад ко входу", on_click=lambda _: show_login_screen())
            ], horizontal_alignment=ft.CrossAxisAlignment.CENTER)
        )
        page.update()

    # --- ГЛАВНЫЙ ЭКРАН (DASHBOARD) ---
    def show_dashboard_screen(): 
        page.clean()

        # 1. ОБЛАСТИ ДЛЯ ДАННЫХ
        doctors_column = ft.Column(scroll="always", spacing=10)
        calendar_zone = ft.Column(expand=True, horizontal_alignment="center")
        def show_confirm_dialog(doctor, time): 
            # Эта функция просто закрывает (для кнопки Назад)
            print(f"Кнопка нажата! Врач: {doctor['name']}, Время: {time}")
            def close_dlg(e):
                dlg.open = False
                page.update()
            # Эта функция СОХРАНЯЕТ и закрывает (для кнопки Записаться)
            def confirm_booking(e):
                all_records = api.load_all_appointments()
                # 2. Создаем новую запись 
                new_app = {
                    "doctor_id": doctor["id"],
                    "doctor_name": doctor["name"],
                    "time": time,
                    "date": session.get("date", "Пн"),
                    "patient_phone": session.get("phone") ,
                }
                
                # 3. Добавляем в локальный список (который точно список, а не функция)
                all_records.append(new_app)
                
                # 4. Сохраняем обратно в файл через API
                api.save_all_appointments(all_records)
                dlg.open = False
                #Обновляем экран 
                render_timetable()
                # Показываем уведомление внизу экрана
                page.snack_bar = ft.SnackBar(ft.Text(f"Вы записаны к врачу {doctor['name']}!"))
                page.snack_bar.open = True
                page.update()

            dlg = ft.AlertDialog(
                title=ft.Text("Детали приема"),
                content=ft.Column([
                    ft.Text(f"Врач: {doctor['name']}", weight="bold"),
                    ft.Text(f"Специальность: {doctor['spec']}"),
                    ft.Text("Опыт работы: 10+ лет"),
                    ft.Text(f"Время: {time}", size=25, color="blue", weight="bold"),
                    ft.Text("Длительность: 60 минут", size=12)
                ], tight=True, spacing=10),
                actions=[
                    # ТУТ ЗАМЕНИЛИ: теперь on_click=confirm_booking
                    ft.ElevatedButton("Записаться", on_click=confirm_booking, bgcolor="blue", color="white"),
                    ft.TextButton("Назад", on_click=close_dlg),
                ],
            )
            page.overlay.append(dlg) # Добавляем
            dlg.open = True          # Команда открыть          
            page.update()             # Обновляем экран
        def show_cancel_dialog(doctor, time):
            def confirm_cancel(e):
                print("Кнопка отмены нажата!") 
                # Вызываем наш метод удаления
                api.cancel_appointment(
                    doctor["id"], 
                    session.get("date", "Пн"), 
                    time,   
                    session.get("phone")
                )
                cancel_dlg.open = False
                print("Метод API вызван!")
                render_timetable() # ПЕРЕРИСОВЫВАЕМ (талон станет синим!)
                page.update()

            cancel_dlg = ft.AlertDialog(
                title=ft.Text("Отмена записи"),
                content=ft.Text(f"Вы действительно хотите отменить запись к врачу {doctor['name']} на {time}?"),
                actions=[
                    ft.TextButton("Да, отменить", on_click=confirm_cancel),
                    ft.TextButton("Нет", on_click=lambda _: (setattr(cancel_dlg, "open", False), page.update()))
                ]
            )
            page.overlay.append(cancel_dlg)
            cancel_dlg.open = True
            page.update()

       
       
        def show_my_appointments(e):
            saved_data=api.load_all_appointments()
            if not saved_data:
                content_ui=ft.Text("У вас пока нет активных записей",size=16 )
            else:
                rows=[]
                for a in saved_data:
                    rows.append(
                        ft.Container(
                            content=ft.Column([
                                # ШАГ 3: Используем ПРАВИЛЬНЫЕ ключи и метод .get()
                                # .get() не даст программе упасть, если ключа нет
                                ft.Text(f"Врач: {a.get('doctor_name', '—')}", weight="bold"),
                                ft.Text(f"Время: {a.get('time', '—')} | Дата: {a.get('date', '—')}"),
                                ft.Divider()
                            ]),
                            padding=10
                        )
                    )
                # ШАГ 4: Этот контейнер должен быть ВНУТРИ блока else
                content_ui = ft.Container(
                    content=ft.Column(rows, scroll="always", tight=True),
                    height=400,
                    width=300
                )

            # Создаем и открываем окно (тут всё было ок)
            appointments_dlg = ft.AlertDialog(
                title=ft.Text("Мои записи в ЕВА"),
                content=content_ui,
                actions=[
                    ft.TextButton("Закрыть", on_click=lambda _: (setattr(appointments_dlg, "open", False), page.update()))
                ]
            )
            # Создаем окно
            appointments_dlg = ft.AlertDialog(
                title=ft.Text("Мои записи в ЕВА"),
                content=content_ui,
                actions=[
                    ft.TextButton("Закрыть", on_click=lambda _: (setattr(appointments_dlg, "open", False), page.update()))
                ]
            )

            # Открываем по нашей проверенной схеме
            page.overlay.append(appointments_dlg)
            appointments_dlg.open = True
            page.update()
        def show_profile(e):
            # Берем данные из session (те, что ввели при входе)
            user_name = session.get("user_name", "Неизвестно")
            user_phone = session.get("phone", "—")
             # Функция для выхода
            def logout(e):
                profile_dlg.open = False # Закрываем окно
                session.clear()          # Очищаем данные (телефон, имя)
                show_login_screen()      # Возвращаем на экран входа
                page.update()
            profile_dlg = ft.AlertDialog( 
                title=ft.Text("Мой профиль"),
                content=ft.Column([
                    ft.Text(f"Имя: {user_name}", size=18, weight="bold"), 
                    ft.Text(f"Телефон: {user_phone}", size=16),
                    ft.Divider(),
                    ft.Text("Статус: Постоянный клиент", color="blue", italic=True)
                ], tight=True),
                actions=[
                    ft.TextButton("Выйти из аккаунта", on_click=logout,),
                    ft.TextButton("Закрыть", on_click=lambda _: (setattr(profile_dlg, "open", False), page.update()))
                ]
            )

            # Наша проверенная схема открытия 
            page.overlay.append(profile_dlg)
            profile_dlg.open = True  
            page.update()

       
        def render_timetable():
            calendar_zone.controls.clear()
            
            # 1. ДНИ НЕДЕЛИ 
            days = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"] 
            days_row = ft.Row(
                [ft.TextButton(d, on_click=lambda e, d=d: select_day(d), 
                               style=ft.ButtonStyle(color="blue" if session.get("date")==d else "black")) 
                 for d in days],
                alignment=ft.MainAxisAlignment.CENTER, spacing=30
            )

            # 2. ШКАЛА ВРЕМЕНИ (8:00 - 16:00)
            times = [f"{h}:00" for h in range(8, 17)]
            time_scale = ft.Row(  
                # alignment убрал, добавил text_align="center" в Text
                [ft.Container(ft.Text(t, size=10, color="grey", text_align="center", no_wrap=True), width=60) for t in times],
                spacing=0, alignment=ft.MainAxisAlignment.CENTER
            )

            # Было: tickets_layout = ft.Column(spacing=15, scroll="always")
            tickets_layout = ft.Column(spacing=15, scroll="always", expand=True) 
            
            
            # 3. ЛОГИКА ВЫВОДА ТАЛОНОВ
                        # 1. Определяем, кого показывать (одного врача или всех по специальности)
            doctors_to_show = []
            if session.get("doctor"):
                doctors_to_show = [session["doctor"]]
            elif session.get("spec"): 
                doctors_to_show = api.get_doctors_by_spec(session["spec"])

            # 2. Очищаем стопку перед наполнением
            tickets_layout.controls.clear()

            # --- ГЛАВНЫЙ ЦИКЛ ПО ВРАЧАМ ---
            for doc in doctors_to_show:
                # СОЗДАЕМ "ПОЛКУ" ДЛЯ ТЕКУЩЕГО ВРАЧА
                print(f"DEBUG: Цикл рисует врача -> {doc['name']}") 
                doc_row = ft.Row(spacing=5, alignment=ft.MainAxisAlignment.CENTER)
                
                slots = api.get_slots(doc["id"], session.get("date", "Пн"))
                
                # ЦИКЛ ПО ЧАСАМ ДЛЯ ЭТОГО ВРАЧА
                for h in range(8, 17):
                    current_time = f"{h:02d}:00"
                    if current_time in slots:
                        # Получаем статус (свободно/занято/мое)
                        status = api.get_slot_status(
                            doc["id"], 
                            session.get("date", "Пн"), 
                            current_time, 
                            session.get("phone")
                        )
                        
                        # Выбираем цвета и действие
                        if status == "mine":
                            color_bg, color_text, click = "green100", "green", lambda e, d=doc, t=current_time: show_cancel_dialog(d, t)
                        elif status == "taken":
                            color_bg, color_text, click = "grey400", "white", None
                        else:
                            color_bg, color_text, click = "blue100", "blue", lambda e, d=doc, t=current_time: show_confirm_dialog(d, t)

                        # Создаем талончик
                        ticket = ft.Container(
                            content=ft.Text(current_time, size=11, color=color_text, weight="bold", text_align="center"),
                            width=60, height=35, # Ширина под шкалу 60-70
                            bgcolor=color_bg, 
                            border_radius=5,
                            border=ft.border.all(1, "blue200"), 
                            on_click=click
                        )
                        doc_row.controls.append(ticket)
                    else:
                        # Пустое место, если врач не работает в этот час
                        doc_row.controls.append(ft.Container(width=60, height=35))

                # КЛАДЕМ ИМЯ ВРАЧА И ЕГО РЯД ТАЛОНОВ В ОБЩУЮ СТОПКУ
                tickets_layout.controls.append(
                    ft.Column([
                        ft.Text(f"👨‍⚕️ {doc['name']} ({doc['spec']})", size=13, weight="bold"),
                        doc_row,
                        ft.Divider(height=10, color="transparent")
                    ], spacing=5)
                )
            # --- КОНЕЦ ЦИКЛА ПО ВРАЧАМ ---

            # 3. ВЫВОДИМ ВСЁ СОБРАННОЕ НА ЭКРАН
            calendar_zone.controls.clear()
            calendar_zone.controls.extend([
                days_row,
                ft.Divider(height=10),
                time_scale,
                ft.Divider(height=5, color="transparent"),
                tickets_layout
            ])
            page.update()




        def select_day(day_name):
            session["date"] = day_name
            render_timetable()

        def select_doctor(doc):
            session["doctor"] = doc
            if not session.get("date"): session["date"] = "Пн"
            render_timetable()

        def select_spec(spec_name):
            doctors_column.controls.clear()
            doctors_column.controls.append(ft.Text(f"Врачи ({spec_name}):", weight="bold", size=16))
            found_doctors = api.get_doctors_by_spec(spec_name)
            for d in found_doctors:
                doctors_column.controls.append( 
                    ft.ListTile(
                        title=ft.Text(d["name"]),
                        on_click=lambda e, doc=d: select_doctor(doc)
                    )
                )
            session["spec"] = spec_name  # Запоминаем, что мы смотрим ЛОРов
            session["doctor"] = None     # СБРАСЫВАЕМ выбор конкретного врача (чтобы показать ВСЕХ)
            render_timetable()
            page.update()

        # --- ТЕПЕРЬ СОБИРАЕМ ИНТЕРФЕЙС ---

        header = ft.Container(
            content=ft.Row([
                ft.Text("МЕДЦЕНТР ЕВА", size=22, weight="bold"), 
                ft.Row([
                    ft.TextButton("Мои записи", on_click=show_my_appointments), 
                    # Было: ft.TextButton(f"Личный кабинет ({session['user_name']})")
                   # Стало:
                ft.TextButton(
                        f"Личный кабинет ({session['user_name']})", 
                        on_click=show_profile # ТЕПЕРЬ ОНА ВЫЗЫВАЕТ ОКНО
                ),

                ])
            ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
            padding=10, bgcolor="blueGrey50"
        )

        spec_column = ft.Column([
            ft.Text("Направления", size=18, weight="bold"),
            ft.Divider(),
            *[ft.ListTile(title=ft.Text(s), on_click=lambda e, s=s: select_spec(s)) 
              for s in api.get_specialties()]
        ])

        layout = ft.Row([
            ft.Container(content=doctors_column, width=180, padding=ft.padding.only(top=10, left=5)),
            ft.Container(content=calendar_zone, expand=True, padding=20),
            ft.Container(content=spec_column, width=180, padding=ft.padding.only(top=10, right=5), bgcolor="blueGrey50"),
        ], expand=True, vertical_alignment=ft.CrossAxisAlignment.START)

        # ДОБАВЛЯЕМ ВСЁ НА СТРАНИЦУ
        page.add(header, layout)
        
        # ЗАПУСКАЕМ ПЕРВОНАЧАЛЬНУЮ ОТРИСОВКУ КАЛЕНДАРЯ
        render_timetable()


       
            
        # -----------------------------------------------




    # Запуск
    show_login_screen()

ft.app(target=main)
