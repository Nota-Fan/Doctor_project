import requests
import json
import os
import sqlite3 
class HospitalAPI:
    def __init__(self):
        self.db_path="hospital_db_db"
        self.offline = True 
        self.init_db()
    def init_db(self): 
        with sqlite3.connect(self.db_path) as conn:
            cursor=conn.cursor() 
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS appointments(
                    id INTEGER PRIMARY KEY AUTOINCREMENT, 
                    doctor_id TEXT, 
                    date TEXT,
                    time TEXT,
                    patient_phone TEXT,
                    doctor_name TEXT
                )
            ''')
            #База данных для пользователей УРАААААААААААА! 
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS users (
                    phone TEXT PRIMARY KEY,
                    password TEXT,
                    name TEXT
                )
            ''')
            # 7. "commit" — это как кнопка "Сохранить" в Word. Без неё ничего не запишется.
            conn.commit()      
    def load_all_appointments(self):
        with sqlite3.connect(self.db_path) as conn:
            # 8. Эта строчка — "переводчик". Она заставляет SQL возвращать данные 
            # не просто списком цифр, а почти готовыми словарями.
            conn.row_factory = sqlite3.Row
            
            cursor = conn.cursor()
            # 9. "SELECT *" — значит "Выбери ВСЕ колонки" из таблицы appointments
            cursor.execute('SELECT * FROM appointments')
            
            # 10. "fetchall" — команда "забери всё, что нашел"
            rows = cursor.fetchall()
            
            # 11. Превращаем "ответы базы" в обычные Python-словари
            # Чтобы main.py видел знакомые: {"doctor_id": "d1", ...}
            return [dict(row) for row in rows]

    def save_all_appointments(self, appointments_list):
        if not appointments_list: return
        
        # Берем данные последней записи
        last = appointments_list[-1]
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            # Посылаем БЛАНК с вопросиками
            query = "INSERT INTO appointments (doctor_id, date, time, patient_phone, doctor_name) VALUES (?, ?, ?, ?, ?)"
            # Посылаем КОНВЕРТ с данными
            data = (last['doctor_id'], last['date'], last['time'], last['patient_phone'], last['doctor_name'])
            
            cursor.execute(query, data)
            conn.commit()
 
    def get_specialties(self):
        """Просто список профессий для правой колонки"""
        return ["ЛОР", "Хирург", "Ортопед", "Стоматолог", "Педиатр", "Гинеколог","Врач лучевой диагностики","Врач лабораторной диагностики","Кардиолог","Нефролог"]

    def get_doctors_by_spec(self, spec_name):
        all_docs = self.get_doctors() 
        # СМОТРИМ В ТЕРМИНАЛ:
        print(f"ИЩЕМ: '{spec_name}'")
        for d in all_docs:
            if d['name'] in ['Фомичкин', 'Махарадзе']:
                print(f"ВРАЧ: {d['name']} | СПЕЦ: '{d['spec']}'")
        
        return [d for d in all_docs if d["spec"].lower().strip() == spec_name.lower().strip()]
 

    # --- ОБНОВЛЕНО: Регистрация (теперь с именем) ---
    def register_user(self, phone, password, name="Пациент"):
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                # SQL-команда: "Вставь в таблицу users"
                cursor.execute(
                    "INSERT INTO users (phone, password, name) VALUES (?, ?, ?)",
                    (phone, password, name) 
                )
                conn.commit()
                return True
        except sqlite3.IntegrityError:
            # Если такой номер уже есть в базе, SQL выдаст ошибку
            print("Ошибка: Пользователь с таким номером уже существует!")
            return False


    def verify_login(self, phone, password): 
        # 1. Подключаемся к базе
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # 2. Ищем пользователя, у которого совпал И ТЕЛЕФОН И ПАРОЛЬ 
            cursor.execute(
                "SELECT * FROM users WHERE phone = ? AND password = ?", 
                (phone, password)
            )
            
            # 3. Пытаемся забрать одну запись
            user = cursor.fetchone()
            
            # 4. Если нашли — возвращаем True (пускаем), если нет — False
            if user:
                return True
            return False


    def get_user_data(self, phone):
        # Идем в базу за данными конкретного пользователя
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            # Ищем по номеру телефона
            cursor.execute("SELECT * FROM users WHERE phone = ?", (phone,))
            row = cursor.fetchone()
            
            if row:
                # Превращаем результат в словарь, чтобы main.py мог взять ['name']
                return dict(row)
            return None


    # --- ОСТАЛЬНОЕ (get_doctors, get_slots и т.д. оставляем как было) ---
    def get_doctors(self):
        # ... твой старый код с try/except и Offline Mode ...
        if self.offline: return self._get_mock_doctors()
        try:
            response = requests.get(f"{self.base_url}/dictionary/doctors", auth=self.auth, timeout=0.1)
            if response.status_code == 200: return response.json()
        except:
            self.offline = True 
        return self._get_mock_doctors()

    def _get_mock_doctors(self):
        return [
            {"id": "d1", "name": "Доктор Кто", "spec": "Педиатр"},
            {"id": "d2", "name": "Хаус", "spec": "Хирург"},
            {"id": "d3", "name": "Быков", "spec": "Терапевт"}, 
            {"id": "d4", "name": "Меркулова", "spec": "Стоматолог"},
            {"id": "d5", "name": "Швец", "spec": "Гинеколог"},
            {"id": "d6", "name": "Смирнов", "spec": "Врач лучевой диагностики"},
            {"id": "d7", "name": "Смирнова", "spec": "Врач лабораторной диагностики"},
            {"id": "d8", "name": "Курулев", "spec": "Кардиолог"},
            {"id": "d9", "name": "Абдрахманов", "spec": "Нефролог"},
            {"id": "d10", "name": "Фомичкин", "spec": "ЛОР"},
            {"id": "d11", "name": "Нагучев", "spec": "Ортопед"},
            {"id": "d12", "name": "Махарадзе", "spec": "ЛОР"},
        ]
    
    def create_appointment(self, doctor_id, patient_phone, date, time):
        if self.offline: return True 
        try:
            payload = {"doctorId": doctor_id, "phone": patient_phone, "date": date, "time": time}
            response = requests.post(f"{self.base_url}/appointment", json=payload, auth=self.auth, timeout=0.1)
            return response.status_code == 201
        except:
            return True 
    def get_slots(self, doctor_id, date):
        if self.offline: return ["09:00", "12:00", "15:00"]
        try:
            params = {"doctor_id": doctor_id, "date": date}
            response = requests.get(f"{self.base_url}/schedule", params=params, auth=self.auth, timeout=0.1)
            if response.status_code == 200:
                return response.json()
        except:
            pass
        return ["09:00", "12:00", "15:00"] 
    #Штука,которая будет проверять доступность талончика, чтобы невозможно было взять 2 одинаковых талончика 
    def get_slot_status(self,doctor_id,date,time,user_phone):
        print(f"--- ПРОВЕРКА ЗАПУЩЕНА для {doctor_id} на {time} ---")
        appointments=self.load_all_appointments()
        for part in appointments:
            print(f"Сравнение: ID('{doctor_id}'=='{part.get('doctor_id')}') | Date('{date}'=='{part.get('date')}') | Time('{time}'=='{part.get('time')}')")
            if (doctor_id==part.get("doctor_id") and  
                date==part.get("date") and
                time==part.get("time")):
                if part.get("patient_phone")==user_phone:
                    return "mine"
                else:
                    return "taken"
        return "free"
    def cancel_appointment(self, doctor_id, date, time, user_phone):
        # 1. Подключаемся к нашей тетрадке (БД)
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # 2. Пишем команду "УДАЛИ" (DELETE)
            # Мы говорим базе: удали из таблицы appointments строку, 
            # где ВСЕ эти четыре условия совпали.
            query = '''
                DELETE FROM appointments 
                WHERE doctor_id = ? AND date = ? AND time = ? AND patient_phone = ?
            '''
            
            # 3. Передаем данные в "конверте" (безопасность!)
            cursor.execute(query, (doctor_id, date, time, user_phone))
            
            # 4. Сохраняем изменения
            conn.commit()

        
       
    



    
            
            