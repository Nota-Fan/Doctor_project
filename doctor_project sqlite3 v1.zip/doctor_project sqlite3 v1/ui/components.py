import flet as ft

def create_doctor_card(doctor, on_click_action):
    # Убрали иконку совсем, оставили только карточку с ФИО и специальностью
    return ft.Card(
        content=ft.Container(
            padding=15,
            content=ft.ListTile(
                title=ft.Text(doctor["name"], size=18, weight="bold"),
                subtitle=ft.Text(doctor["spec"]),
                on_click=lambda _: on_click_action(doctor) 
            )
        )
    )
