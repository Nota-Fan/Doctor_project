import requests
import json
import os
class HospitalAPI:
    def __init__(self):
        self.base_url = "http://127.0.0"
        self.auth = ("ClinicAPI", "artem")
        self.offline = False 
        # Наша база пользователей (теперь с именами)
        self.users_db = {"9001234567": {"pass": "1234", "name": "Иван Иванов"}} 
    def load_all_appointments(self):
        if os.path.exists("database.json"):
            with open("database.json","r", encoding="utf-8") as f:
              return json.load(f)
        else:
            return[]
    def save_all_appointments(self, appointment_list):
        with open("database.json","w",encoding="utf-8") as f:
            return json.dump(appointment_list,f,ensure_ascii=False,indent=4) 
    # --- НОВОЕ: Работа со специальностями --- 
    def get_specialties(self):
        """Просто список профессий для правой колонки"""
        return ["ЛОР", "Хирург", "Ортопед", "Стоматолог", "Педиатр", "Гинеколог","Врач лучевой диагностики","Врач лабораторной диагностики","Кардиолог","Нефролог"]

    def get_doctors_by_spec(self, spec_name):
        """Берет всех врачей и оставляет только нужной профессии"""
        all_docs = self.get_doctors()
        return [d for d in all_docs if d["spec"] == spec_name]

    # --- ОБНОВЛЕНО: Регистрация (теперь с именем) ---
    def register_user(self, phone, password, name):
        if phone not in self.users_db:
            self.users_db[phone] = {"pass": password, "name": name}
            return True
        return False

    def verify_login(self, phone, password):
        user = self.users_db.get(phone)
        if user and user["pass"] == password:
            return True
        return False

    def get_user_data(self, phone):
        """Метод, чтобы личный кабинет знал, как зовут пользователя"""
        user = self.users_db.get(phone)
        if user:
            return {"name": user["name"], "phone": phone}
        return {"name": "Пациент", "phone": phone}

    # --- ОСТАЛЬНОЕ (get_doctors, get_slots и т.д. оставляем как было) ---
    def get_doctors(self):
        # ... твой старый код с try/except и Offline Mode ...
        if self.offline: return self._get_mock_doctors()
        try:
            response = requests.get(f"{self.base_url}/dictionary/doctors", auth=self.auth, timeout=0.1)
            if response.status_code == 200: return response.json()
        except:
            self.offline = True 
        return self._get_mock_doctors()

    def _get_mock_doctors(self):
        return [
            {"id": "d1", "name": "Доктор Кто", "spec": "Педиатр"},
            {"id": "d2", "name": "Хаус", "spec": "Хирург"},
            {"id": "d3", "name": "Быков", "spec": "Терапевт"},
            {"id": "d4", "name": "Меркулова", "spec": "Стоматолог"},
            {"id": "d5", "name": "Швец", "spec": "Гинеколог"},
            {"id": "d6", "name": "Смирнов", "spec": "Врач лучевой диагностики"},
            {"id": "d7", "name": "Смирнова", "spec": "Врач лабораторной диагностики"},
            {"id": "d8", "name": "Курулев", "spec": "Кардиолог"},
            {"id": "d9", "name": "Абдрахманов", "spec": "Нефролог"},
            {"id": "d10", "name": "Фомичкин", "spec": "ЛОР"},
            {"id": "d11", "name": "Нагучев", "spec": "Ортопед"},
            {"id": "d12", "name": "Махарадзе", "spec": "ЛОР"},
        ]
    
    def create_appointment(self, doctor_id, patient_phone, date, time):
        if self.offline: return True 
        try:
            payload = {"doctorId": doctor_id, "phone": patient_phone, "date": date, "time": time}
            response = requests.post(f"{self.base_url}/appointment", json=payload, auth=self.auth, timeout=0.1)
            return response.status_code == 201
        except:
            return True 
    def get_slots(self, doctor_id, date):
        if self.offline: return ["09:00", "12:00", "15:00"]
        try:
            params = {"doctor_id": doctor_id, "date": date}
            response = requests.get(f"{self.base_url}/schedule", params=params, auth=self.auth, timeout=0.1)
            if response.status_code == 200:
                return response.json()
        except:
            pass
        return ["09:00", "12:00", "15:00"] 
    #Штука,которая будет проверять доступность талончика, чтобы невозможно было взять 2 одинаковых талончика 
    def get_slot_status(self,doctor_id,date,time,user_phone):
        print(f"--- ПРОВЕРКА ЗАПУЩЕНА для {doctor_id} на {time} ---")
        appointments=self.load_all_appointments()
        for part in appointments:
            print(f"Сравнение: ID('{doctor_id}'=='{part.get('doctor_id')}') | Date('{date}'=='{part.get('date')}') | Time('{time}'=='{part.get('time')}')")
            if (doctor_id==part.get("doctor_id") and  
                date==part.get("date") and
                time==part.get("time")):
                if part.get("patient_phone")==user_phone:
                    return "mine"
                else:
                    return "taken"
        return "free"
    def cancel_appointment(self, doctor_id, date, time, user_phone):
        # 1. Грузим все записи
        appointments = self.load_all_appointments()
        
        # 2. Оставляем только те, которые НЕ совпадают с нашими данными
        # (Мы проверяем еще и телефон, чтобы нельзя было случайно отменить чужую запись!)
        new_list = [app for app in appointments if not (
            app.get("doctor_id") == doctor_id and 
            app.get("date") == date and 
            app.get("time") == time and
            app.get("patient_phone") == user_phone
        )]
        
        # 3. Сохраняем обновленный список
        self.save_all_appointments(new_list)

    



    
            
            